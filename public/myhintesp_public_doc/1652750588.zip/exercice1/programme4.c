#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	pid_t valeur, valeur1;
	printf("affichage 1 --> Processus pere [%d]  : mon pere a moi est [%d]\n", getpid(), getppid());
	valeur = fork();
	printf("affichage2 --> retour fork [%d] - Processus fils [%d]; mon pere est [%d] \n", valeur, getpid(), getppid());
	valeur1 = fork();
	printf("affichage3 --> retour fork [%d] - Processus fils [%d]; mon pere est [%d] \n", valeur1, getpid(), getppid());
	return 0;
}