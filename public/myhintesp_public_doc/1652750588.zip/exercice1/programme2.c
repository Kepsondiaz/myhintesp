#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#define N 10
int  main(int argc, char *argv[])
{
	int i = 1;
	while (fork() == 0 && i<=N) 
		{i++;}
	printf("%d\n",i);
	exit(0);
	return 0;
} 