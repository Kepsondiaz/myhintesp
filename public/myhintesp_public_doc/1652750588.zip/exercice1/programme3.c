#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int pid[3], i;
	for(i==0; i<3; ++i){
		pid[i]=fork();
	}
	printf("%d %d %d\n", pid[0] , pid[1] , pid[2]);
	return 0;
}
